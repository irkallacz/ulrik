Toto jsou soubory pravidel z LARPové bitvy Warhammer - The Other Sides IV

Pravidla jsou uspořádány do složek podle Warband (národa, družin nebo jak tomu chcete říkat). Pravidla každé postavy se skládají ze základního souboru (například noble.xml), který obsahuje základní vlastnosti a schopnosti dané postavy a potom ze souboru s koncovkou '_wargear', který obsahuje dodatečná schopnosti, kouzla a předměty, které si mohla daná postava zakoupit (viz například 'noble_wargear.xml'). 

Soubory jsou ve formátu XML a je použito kódování UTF8. Měli byste je být schopni otevřít v Poznámkovém bloku nebo ve Vašem internetovém prohlížeči.

Pokud byste rádi  pravidlům více rozuměli, stáhněte si ukázkové soubory http://ulrik.irkalla.cz/file/noble.xml a http://ulrik.irkalla.cz/file/noble_wargear.pdf, které obsahují velké množství poznámek. 

V pravidlech můžete narazit na výrazy, které se mohou vztahovat k obecným pravidlům naší bitvy. Ty si můžete stáhnout na adrese http://ulrik.irkalla.cz/file/pravidla.pdf.

Pokud Vám pravidla pomohou a budete je chtít použít na nějaké své akci, dejte nám prosím vědět na adresu faila@atlas.cz

Děkuji

Richard Faila