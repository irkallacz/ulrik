<?php

class ExtraPresenter extends BasePresenter{

}
